/**
  * @file fileFunctions.h
  * @version 1.0
  * @date 21/03/2020
  * @author Esperanza Manuel
  * @brief prototipos de las funciones que utiliza el file server. 
  */